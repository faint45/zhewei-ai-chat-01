--
-- PostgreSQL database dump
--

\restrict nKoHx8huxC4QkpDgaUNfJAHN9wcWDuPyfA5c7bnqtHVkLPmYHayaGyLIXZ9qx4L

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.usage_records DROP CONSTRAINT IF EXISTS usage_records_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.usage_records DROP CONSTRAINT IF EXISTS usage_records_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS api_keys_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS api_keys_tenant_id_fkey;
DROP INDEX IF EXISTS public.idx_users_tenant;
DROP INDEX IF EXISTS public.idx_users_email;
DROP INDEX IF EXISTS public.idx_usage_records_user;
DROP INDEX IF EXISTS public.idx_usage_records_tenant;
DROP INDEX IF EXISTS public.idx_usage_records_date;
DROP INDEX IF EXISTS public.idx_payments_user;
DROP INDEX IF EXISTS public.idx_payments_status;
DROP INDEX IF EXISTS public.idx_api_keys_hash;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.usage_records DROP CONSTRAINT IF EXISTS usage_records_pkey;
ALTER TABLE IF EXISTS ONLY public.usage_daily_summary DROP CONSTRAINT IF EXISTS usage_daily_summary_pkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_slug_key;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_pkey;
ALTER TABLE IF EXISTS ONLY public.subscription_plans DROP CONSTRAINT IF EXISTS subscription_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_pkey;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS api_keys_pkey;
ALTER TABLE IF EXISTS public.usage_records ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.usage_records_id_seq;
DROP TABLE IF EXISTS public.usage_records;
DROP TABLE IF EXISTS public.usage_daily_summary;
DROP TABLE IF EXISTS public.tenants;
DROP TABLE IF EXISTS public.subscription_plans;
DROP TABLE IF EXISTS public.payments;
DROP TABLE IF EXISTS public.api_keys;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    tenant_id uuid,
    key_hash text NOT NULL,
    key_prefix text NOT NULL,
    name text DEFAULT 'default'::text NOT NULL,
    scopes text[] DEFAULT '{}'::text[],
    rate_limit_per_min integer DEFAULT 30,
    expires_at timestamp with time zone,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    tenant_id uuid,
    amount_ntd integer NOT NULL,
    currency text DEFAULT 'TWD'::text NOT NULL,
    payment_method text DEFAULT 'ecpay'::text NOT NULL,
    payment_id text,
    status text DEFAULT 'pending'::text NOT NULL,
    plan text,
    period_start date,
    period_end date,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    monthly_calls integer DEFAULT 100 NOT NULL,
    monthly_tokens integer DEFAULT 50000 NOT NULL,
    price_ntd integer DEFAULT 0 NOT NULL,
    features jsonb DEFAULT '{}'::jsonb,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    plan text DEFAULT 'free'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: usage_daily_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage_daily_summary (
    date date NOT NULL,
    user_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL,
    tenant_id uuid,
    provider text NOT NULL,
    total_calls integer DEFAULT 0 NOT NULL,
    total_tokens integer DEFAULT 0 NOT NULL,
    total_cost_usd numeric(10,6) DEFAULT 0 NOT NULL,
    success_count integer DEFAULT 0 NOT NULL,
    error_count integer DEFAULT 0 NOT NULL,
    avg_duration_ms real DEFAULT 0 NOT NULL
);


--
-- Name: usage_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage_records (
    id bigint NOT NULL,
    ts double precision NOT NULL,
    date date NOT NULL,
    user_id uuid,
    tenant_id uuid,
    provider text NOT NULL,
    model text NOT NULL,
    task_type text DEFAULT 'chat'::text NOT NULL,
    input_tokens integer DEFAULT 0 NOT NULL,
    output_tokens integer DEFAULT 0 NOT NULL,
    total_tokens integer DEFAULT 0 NOT NULL,
    duration_ms integer DEFAULT 0 NOT NULL,
    estimated_cost_usd numeric(10,6) DEFAULT 0 NOT NULL,
    success boolean DEFAULT true NOT NULL,
    error_msg text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: usage_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usage_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usage_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.usage_records_id_seq OWNED BY public.usage_records.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    username text NOT NULL,
    email text,
    password_hash text NOT NULL,
    password_salt text NOT NULL,
    role text DEFAULT 'pending'::text NOT NULL,
    subscription text DEFAULT 'pending'::text NOT NULL,
    subscription_plan text DEFAULT ''::text,
    subscription_expires_at timestamp with time zone,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: usage_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_records ALTER COLUMN id SET DEFAULT nextval('public.usage_records_id_seq'::regclass);


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_keys (id, user_id, tenant_id, key_hash, key_prefix, name, scopes, rate_limit_per_min, expires_at, last_used_at, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, user_id, tenant_id, amount_ntd, currency, payment_method, payment_id, status, plan, period_start, period_end, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_plans (id, name, monthly_calls, monthly_tokens, price_ntd, features, active, created_at) FROM stdin;
free	免費版	100	50000	0	{"roles": 3, "kb_size": 2000}	t	2026-02-14 02:01:38.344523+00
basic	基礎版	1000	500000	499	{"roles": 9, "kb_size": 20000, "workflow": true}	t	2026-02-14 02:01:38.344523+00
pro	專業版	5000	2000000	999	{"roles": 15, "vision": true, "kb_size": 50000, "workflow": true}	t	2026-02-14 02:01:38.344523+00
enterprise	企業版	-1	-1	4999	{"api": true, "roles": -1, "vision": true, "kb_size": -1, "support": true, "workflow": true}	t	2026-02-14 02:01:38.344523+00
unlimited	無限版	-1	-1	0	{"roles": -1, "kb_size": -1, "internal": true}	t	2026-02-14 02:01:38.344523+00
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (id, name, slug, plan, status, settings, created_at, updated_at) FROM stdin;
019cbb1d-ed3c-49c7-bac8-57dd42461a4a	測試營建公司	test_construction	pro	active	{}	2026-02-14 02:07:12.414657+00	2026-02-14 02:07:12.414657+00
\.


--
-- Data for Name: usage_daily_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usage_daily_summary (date, user_id, tenant_id, provider, total_calls, total_tokens, total_cost_usd, success_count, error_count, avg_duration_ms) FROM stdin;
\.


--
-- Data for Name: usage_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usage_records (id, ts, date, user_id, tenant_id, provider, model, task_type, input_tokens, output_tokens, total_tokens, duration_ms, estimated_cost_usd, success, error_msg, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, tenant_id, username, email, password_hash, password_salt, role, subscription, subscription_plan, subscription_expires_at, last_login_at, created_at, updated_at) FROM stdin;
1b35fdd7-1647-4c77-aa0c-21d9419165e6	\N	allen34556	\N	47c65e06b9f3481868360f6dad6c519e341e83517def2622ae49f1772deb1695	45db7cc4725eb32505ba7581748a551f	superadmin	active	unlimited	\N	2026-02-26 18:32:21.599927+00	2026-02-14 00:47:35+00	2026-02-14 02:01:38.41874+00
\.


--
-- Name: usage_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usage_records_id_seq', 1, false);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: usage_daily_summary usage_daily_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_daily_summary
    ADD CONSTRAINT usage_daily_summary_pkey PRIMARY KEY (date, user_id, provider);


--
-- Name: usage_records usage_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_records
    ADD CONSTRAINT usage_records_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_api_keys_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_hash ON public.api_keys USING btree (key_hash);


--
-- Name: idx_payments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_status ON public.payments USING btree (status);


--
-- Name: idx_payments_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_user ON public.payments USING btree (user_id);


--
-- Name: idx_usage_records_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_records_date ON public.usage_records USING btree (date);


--
-- Name: idx_usage_records_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_records_tenant ON public.usage_records USING btree (tenant_id, date);


--
-- Name: idx_usage_records_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_records_user ON public.usage_records USING btree (user_id, date);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_tenant ON public.users USING btree (tenant_id);


--
-- Name: api_keys api_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payments payments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: payments payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: usage_records usage_records_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_records
    ADD CONSTRAINT usage_records_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: usage_records usage_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_records
    ADD CONSTRAINT usage_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict nKoHx8huxC4QkpDgaUNfJAHN9wcWDuPyfA5c7bnqtHVkLPmYHayaGyLIXZ9qx4L

